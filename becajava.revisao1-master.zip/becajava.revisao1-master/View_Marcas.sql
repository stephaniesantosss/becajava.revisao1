
CREATE VIEW VW_MARCA

AS 
Select 
	Marca.Descricao
	
	
FROM Marca
 

 Select * From VW_MARCA