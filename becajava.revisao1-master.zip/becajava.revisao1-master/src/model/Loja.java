package model;

public class Loja {
	
	public int Id;
	public int VendedorId;
	public String Nome;
	public String CNPJ;
	
}
