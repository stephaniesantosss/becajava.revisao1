package model;

public class Veiculo {

	public int Id;
	public int Valor;
	public int TipoVeiculoId;
	public int MarcaId;
	public String Placa;
	public String Nome;
}
