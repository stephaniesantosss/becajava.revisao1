package model;

public class Vendedor {
	
	public int Id;
	public int Matricula;
	public String Nome;
	
}
