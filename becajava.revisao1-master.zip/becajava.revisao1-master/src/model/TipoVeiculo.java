package model;

public class TipoVeiculo {
	public int Id;
	public String Descricao;
}
