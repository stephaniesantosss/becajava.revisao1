package model;

public class Marca {

	public int Id;
	public  String Descricao;
}
