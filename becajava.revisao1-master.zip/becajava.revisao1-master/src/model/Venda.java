package model;

public class Venda {

	public int Id;
	public int ClienteId;
	public int VendedorId;
	public int VeiculoId;
	public String DataVenda;
}
