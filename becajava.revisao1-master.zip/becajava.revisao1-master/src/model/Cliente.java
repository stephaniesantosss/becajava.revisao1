package model;

public class Cliente {

	public int Id;
	public String Nome;
	public String Cpf;
	

}
