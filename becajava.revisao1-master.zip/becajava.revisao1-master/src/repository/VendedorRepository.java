package repository;

import java.util.ArrayList;
import java.util.List;

import model.Vendedor;

public class VendedorRepository {
	public List<Vendedor> Lista = new ArrayList<Vendedor>();

	public Vendedor GetVendedor(int indice) {
		return new Vendedor();
	}

	public List<Vendedor> GetAllVendedor(int indice) {
		return new ArrayList<Vendedor>();
	}

	public void SetVendedor(Vendedor vendedor) {

	}
}