package repository;

import java.util.ArrayList;
import java.util.List;

import model.Marca;

public class MarcaRepository {
	public List< Marca> Lista = new ArrayList< Marca>();

	public  Marca GetMarca(int indice) {
		return new  Marca();
	}

	public List< Marca> GetAllMarca(int indice) {
		return new ArrayList< Marca>();
	}

	public void SetMarca( Marca marca) {

	}
}