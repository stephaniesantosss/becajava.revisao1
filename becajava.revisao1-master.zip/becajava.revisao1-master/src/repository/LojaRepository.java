package repository;

import java.util.ArrayList;
import java.util.List;

import model.Loja;

	public class LojaRepository {
		public List< Loja> Lista = new ArrayList< Loja>();

		public  Loja GetLoja(int indice) {
			return new  Loja();
		}

		public List< Loja> GetAllLoja(int indice) {
			return new ArrayList< Loja>();
		}

		public void SetLoja( Loja loja) {

		}
	}


