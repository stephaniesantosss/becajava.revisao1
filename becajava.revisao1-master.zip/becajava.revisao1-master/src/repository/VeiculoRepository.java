package repository;

import java.util.ArrayList;
import java.util.List;

import model.Veiculo;

public class VeiculoRepository {
	public List<Veiculo> Lista = new ArrayList<Veiculo>();

	public Veiculo GetVeiculo(int indice) {
		return new Veiculo();
	}

	public List<Veiculo> GetAllVeiculo(int indice) {
		return new ArrayList<Veiculo>();
	}

	public void SetVeiculo(Veiculo veiculo) {

	}
}