package repository;

import java.util.ArrayList;
import java.util.List;

import model.Venda;


public class VendaRepository {
	public List<Venda> Lista = new ArrayList<Venda>();

	public Venda GetVenda(int indice) {
		return new Venda();
	}

	public List<Venda> GetAllVenda(int indice) {
		return new ArrayList<Venda>();
	}

	public void SetVenda(Venda venda) {

	}
}