
CREATE VIEW VW_VENDEDOR

AS 
Select 
	Vendedor.Nome,
	Vendedor.Id
	
FROM Vendedor
