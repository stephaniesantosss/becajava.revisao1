
CREATE VIEW [dbo].[VW_LOJA]

AS 
Select 
	Loja.Nome,
	Loja.CNPJ
	
FROM Loja 



