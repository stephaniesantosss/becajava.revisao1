
CREATE VIEW VW_CPF

AS 
Select 
	Cliente.CPF
	
FROM Cliente
