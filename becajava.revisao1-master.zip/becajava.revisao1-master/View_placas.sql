
CREATE VIEW VW_PLACA

AS 
Select 
	Veiculo.Placa,
	Veiculo.Nome
	
FROM Veiculo
